CREATE TABLE [dbo].[Blazor_users] (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    user_name NVARCHAR(50) NOT NULL,
    password NVARCHAR(255) NOT NULL
);

use TEST_BLAZOR

INSERT INTO [dbo].[Blazor_users] (user_name, password)
VALUES ('testuser', 'password123'), ('admin', 'adminpass');


INSERT INTO [dbo].[Blazor_users] (user_name, password)
VALUES ('testuser', HASHBYTES('SHA2_256', 'password123'));


ALTER TABLE [dbo].[Blazor_users]
ADD 
    login_timestamp DATETIME NULL,             -- When the user logged in
    last_login DATETIME NULL,                  -- Last successful login
    attempt_login INT DEFAULT 0 NOT NULL,      -- Count of login attempts
    last_change_password DATETIME NULL,        -- When the password was last changed
    level NVARCHAR(50) NULL,                   -- User level (e.g., Admin, User, etc.)
    ip_address NVARCHAR(50) NULL,              -- IP address of the last login
    password_expire_date DATETIME NULL;        -- Password expiration date

select * from Blazor_users;


ALTER TABLE Blazor_users ADD CONSTRAINT PK_Blazor_users PRIMARY KEY (user_id);
