﻿using Microsoft.EntityFrameworkCore;
using BlazorServerFileUpload.Models;

namespace BlazorServerFileUpload.db
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options) { }

        public DbSet<BlazorUser> Blazor_users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Map this entity to the "Blazor_users" table
            modelBuilder.Entity<BlazorUser>().ToTable("Blazor_users");

            // Mark user_id as primary key
            modelBuilder.Entity<BlazorUser>().HasKey(u => u.user_id);
        }
    }
}
