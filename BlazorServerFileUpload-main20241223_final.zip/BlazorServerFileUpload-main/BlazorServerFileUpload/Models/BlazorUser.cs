﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BlazorServerFileUpload.Models
{
    public class BlazorUser
    {
        [Key]
        public int user_id { get; set; } // Primary Key

        public string user_name { get; set; } = string.Empty; // Username
        public string password { get; set; } = string.Empty;  // Stored as a BCrypt hash

        // Other optional fields
        public DateTime? login_timestamp { get; set; }
        public DateTime? last_login { get; set; }
        public int attempt_login { get; set; }
        public DateTime? last_change_password { get; set; }
        public string? level { get; set; }
        public string? ip_address { get; set; }
        public DateTime? password_expire_date { get; set; }
    }
}
