﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using System.IO;

[Route("[controller]")]
public class FileDownloadController : Controller
{
    private readonly IWebHostEnvironment _env;

    public FileDownloadController(IWebHostEnvironment env)
    {
        _env = env;
    }

    /// <summary>
    /// Download the file as an attachment (forces "Save File" in most browsers).
    /// Usage: GET /FileDownload/DownloadFile?fileName=Test.pdf
    /// </summary>
    [HttpGet("DownloadFile")]
    public IActionResult DownloadFile([FromQuery] string fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName))
            return BadRequest("No file name provided.");

        var appDataPath = Path.Combine(_env.ContentRootPath, "AppData");
        var fullPath = Path.Combine(appDataPath, fileName);

        if (!System.IO.File.Exists(fullPath))
            return NotFound("File not found.");

        var fileBytes = System.IO.File.ReadAllBytes(fullPath);
        return File(fileBytes, "application/octet-stream", fileName);
    }

    /// <summary>
    /// View the file inline if supported (e.g., PDF in browser).
    /// Usage: GET /FileDownload/ViewFile?fileName=Test.pdf
    /// </summary>
    [HttpGet("ViewFile")]
    public IActionResult ViewFile([FromQuery] string fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName))
            return BadRequest("No file name provided.");

        var appDataPath = Path.Combine(_env.ContentRootPath, "AppData");
        var fullPath = Path.Combine(appDataPath, fileName);

        if (!System.IO.File.Exists(fullPath))
            return NotFound("File not found.");

        var fileBytes = System.IO.File.ReadAllBytes(fullPath);
        var contentType = GetContentTypeByExtension(fullPath);

        return File(fileBytes, contentType);
    }

    /// <summary>
    /// Delete a file from AppData.
    /// Usage: DELETE /FileDownload/DeleteFile?fileName=Test.pdf
    /// </summary>
    [HttpDelete("DeleteFile")]
    public IActionResult DeleteFile([FromQuery] string fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName))
            return BadRequest("No file name provided.");

        var appDataPath = Path.Combine(_env.ContentRootPath, "AppData");
        var fullPath = Path.Combine(appDataPath, fileName);

        if (!System.IO.File.Exists(fullPath))
            return NotFound("File not found.");

        try
        {
            System.IO.File.Delete(fullPath);
        }
        catch (Exception ex)
        {
            return BadRequest($"Could not delete file: {ex.Message}");
        }

        return Ok($"File '{fileName}' deleted successfully.");
    }

    /// <summary>
    /// Simple helper to determine MIME type from file extension.
    /// </summary>
    private string GetContentTypeByExtension(string filePath)
    {
        var ext = Path.GetExtension(filePath).ToLowerInvariant();
        return ext switch
        {
            ".pdf" => "application/pdf",
            ".txt" => "text/plain",
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png" => "image/png",
            ".gif" => "image/gif",
            _ => "application/octet-stream",
        };
    }
}
