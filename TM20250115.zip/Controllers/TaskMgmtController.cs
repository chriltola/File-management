using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Serialization;
using WebAppTaskMgmt.Models;

namespace WebAppTaskMgmt.Controllers
{

    public partial class TaskMgmtController(ILogger<TaskMgmtController> pvLogger, IConfiguration pvConfiguration, IHttpClientFactory pvIHttpClientFactory) : Controller
    {

        #region ---------- Class Variable ---------------------------------------------------------------------------------
        private readonly ILogger<TaskMgmtController> cvLogger = pvLogger;
        private readonly IConfiguration cvConfiguration = pvConfiguration;
        private readonly IHttpClientFactory cvHttpClientFactory = pvIHttpClientFactory;

        private readonly string cvTargetFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
        private readonly string _allowFileType = "application/pdf";
        private readonly long _maxFileSize = 2 * 1024 * 1024; // 2MB

        #endregion

        #region ---------- Record - Response ------------------------------------------------------------------------------

        public record WebApiReturnResultForTreeView
        {

            [JsonPropertyName("code")]
            public int Code { get; set; }

            [JsonPropertyName("message")]
            public string Message { get; set; }

            [JsonPropertyName("note")]
            public string Note { get; set; }

            [JsonPropertyName("jsonData")]
            public CPBTreeNode[] JsonData { get; set; }
        }

        #endregion

        record Ab { public string TaskId { get; set; } }

        #region ---------- Index ------------------------------------------------------------------------------------------
        public IActionResult Index()
        {
            string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
            if (string.IsNullOrEmpty(lvToken)) { return RedirectToAction("Index", "Login"); }
            else
            {
                //string lvBaseAddress = cvConfiguration.GetSection("WebApiEndpoint")["TaskMgmt"];
                string lvAccessToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
                var lvTreViewDataFromDB = GetTreeViewData(lvAccessToken, 0);
                if (lvTreViewDataFromDB is null) return View();
                else
                {
                    if (lvTreViewDataFromDB.Result is null)
                    {
                        ViewBag.CPBTreeViewHTML = "";
                        return View();
                    }
                    else
                    {
                        List<CPBTreeNode> lvTreeNodeList = [];
                        foreach (var lvTreeNode in lvTreViewDataFromDB.Result.JsonData) lvTreeNodeList.Add(lvTreeNode);
                        var lvCPBTreeViewHTML = Generate_CPBTreeView(lvTreeNodeList);
                        ViewBag.CPBTreeViewHTML = lvCPBTreeViewHTML;
                        return View();
                    }
                }
            }
        }

        #endregion

        #region ---------- Verb Task Path ---------------------------------------------------------------------------------

        //////////////////////////////////////////////////////////////////////////////////////// Create Task Path
        [HttpPost]
        public async Task<IActionResult> Create_TaskPath(TaskPathModel pvTask)
        {
            try
            {
                string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
                if (string.IsNullOrEmpty(lvToken)) { return RedirectToAction("Index", "Login"); }
                else
                {
                    var lvClient = cvHttpClientFactory.CreateClient("TaskMgmtClient");
                    lvClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {lvToken}");
                    var lvLoginData = new
                    {

                        parentId = pvTask.ParentId,
                        shortName = pvTask.ShortName,
                        sortIndex = pvTask.SortIndex
                        //note == null
                    };
                    var lvJsonData = JsonConvert.SerializeObject(lvLoginData);
                    var lvContent = new StringContent(lvJsonData, Encoding.UTF8, "application/json");
                    var lvResponse = await lvClient.PostAsync("V1/TaskPath", lvContent);
                    string lvReturnDataData = await lvResponse.Content.ReadAsStringAsync();
                    if (lvResponse.IsSuccessStatusCode)
                    {
                        lvClient.Dispose();
                        return RedirectToAction("Index", "TaskMgmt");
                    }
                    else
                    {
                        lvClient.Dispose();
                        return BadRequest(lvReturnDataData);
                    }
                }
            }
            catch (Exception exc)
            {
                return null;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////// Update TaskPath
        [HttpPost]
        public IActionResult Edit_TaskPath(TaskPathModel pvTaskId)
        {
            try
            {
                string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
                if (string.IsNullOrEmpty(lvToken)) { return RedirectToAction("Index", "Login"); }
                else
                {
                    string lvBaseAddress = cvConfiguration.GetSection("WebApiEndpoint")["TaskMgmt"];
                    if (string.IsNullOrEmpty(lvBaseAddress)) { return null; }
                    HttpClientHandler HttpClientHandler = new() { ServerCertificateCustomValidationCallback = (message, cert, chain, sslPolicyErrors) => { return true; } };
                    var lvHttpClient = new HttpClient(HttpClientHandler)
                    {
                        BaseAddress = new Uri(lvBaseAddress)
                    };
                    lvHttpClient.BaseAddress = new Uri(lvBaseAddress);
                    lvHttpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + lvToken);
                    var lvLoginData = new
                    {
                        pvTaskId.TaskPathId,
                        parentId = "",
                        shortName = pvTaskId.ShortName
                        //note == null
                    };
                    var lvJsonData = JsonConvert.SerializeObject(lvLoginData);
                    var lvContent = new StringContent(lvJsonData, Encoding.UTF8, "application/json");
                    // SendPost
                    HttpResponseMessage lvHttpRespMsg = lvHttpClient.PutAsync($"V1/TaskPath", lvContent).Result;
                    if (lvHttpRespMsg.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index", "TaskMgmt");
                    }
                    else
                    {
                        return BadRequest(lvHttpRespMsg.Content); ;
                    }
                }
            }
            catch (Exception exc)
            {
                return null;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////// Delete TaskPath
        public IActionResult Delete_TaskPath(TaskPathModel pvTaskId)
        {
            try
            {
                string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
                if (string.IsNullOrEmpty(lvToken)) { return RedirectToAction("Index", "Login"); }
                else
                {
                    string lvBaseAddress = cvConfiguration.GetSection("WebApiEndpoint")["TaskMgmt"];
                    if (string.IsNullOrEmpty(lvBaseAddress)) { return null; }
                    HttpClientHandler HttpClientHandler = new()
                    {
                        ServerCertificateCustomValidationCallback
                    = (message, cert, chain, sslPolicyErrors) => { return true; }
                    };
                    var lvHttpClient = new HttpClient(HttpClientHandler)
                    {
                        BaseAddress = new Uri(lvBaseAddress)
                    };
                    lvHttpClient.BaseAddress = new Uri(lvBaseAddress);
                    lvHttpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + lvToken);
                    var lvLoginData = new
                    {
                        pvTaskId.TaskPathId
                    };
                    var request = new HttpRequestMessage
                    {
                        Method = HttpMethod.Delete,
                        RequestUri = new Uri($"{lvBaseAddress}V1/TaskPath"),
                        Content = new StringContent(JsonConvert.SerializeObject(lvLoginData), Encoding.UTF8, "application/json")
                    };
                    var response = lvHttpClient.SendAsync(request).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index", "TaskMgmt");
                    }
                    else
                    {
                        return BadRequest(response.Content); ;
                    }
                }
            }
            catch (Exception exc)
            {
                return null;
            }
        }

        #endregion

        #region ---------- Verb CPB Task ----------------------------------------------------------------------------------

        ////////////////////////////////////////////////////////////////////////////////////////  Create CPBTask
        [HttpPost]
        public async Task<IActionResult> Create_CPBTask([FromForm] CPBTaskModel pvInputModel)
        {
            if (pvInputModel.FileToUpload is null) return BadRequest("File not found.");
            /////////////////////////////////////////////////////////////////////////////////
            string TaskId = "T89"; // Temporary test
            /////////////////////////////////////////////////////////////////////////////////
            string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
            var lvClient1 = cvHttpClientFactory.CreateClient("TaskMgmtClient");
            lvClient1.DefaultRequestHeaders.Add("Authorization", $"Bearer {lvToken}");
            lvClient1.DefaultRequestHeaders.Add("cache-control", "no-cache");
            using (var lvMFContent = new MultipartFormDataContent())
            {
                lvMFContent.Add(new StringContent(TaskId), name: "TaskId");

                var lvFSContent = new StreamContent(pvInputModel.FileToUpload.OpenReadStream());
                lvFSContent.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
                lvMFContent.Add(lvFSContent, name: "FileToUpload", fileName: pvInputModel.FileToUpload.Name);

                var lvResponse1 = await lvClient1.PostAsync("V1/CPBTaskAttchmnt", lvMFContent);
                //lvResponse1.EnsureSuccessStatusCode();
                string lvReturnDataData1 = await lvResponse1.Content.ReadAsStringAsync();
                if (lvResponse1.IsSuccessStatusCode)
                {
                    return Ok(lvReturnDataData1);
                }
                else
                {
                    lvClient1.Dispose();
                    return BadRequest(lvReturnDataData1);
                }
            }

        }

        //public async Task<IActionResult> Create_CPBTask_Old([FromForm] CPBTaskModel pvInputModel)
        //{
        //    if (pvInputModel.FileToUpload is null) return BadRequest("File not found.");

        //    //return Task.FromResult<IActionResult>(RedirectToAction("Index", "TaskMgmt"));
        //    try
        //    {
        //        //if (!Directory.Exists(cvTargetFolder))
        //        //{
        //        //    Directory.CreateDirectory(cvTargetFolder);
        //        //}
        //        //foreach (var file in files)
        //        //{
        //        //    //if (file.Length > 0)
        //        //    //{
        //        //    //    var filePath = Path.Combine(cvTargetFolder, file.FileName);
        //        //    //    using var stream = new FileStream(filePath, FileMode.Create);
        //        //    //    await file.CopyToAsync(stream);
        //        //    //}
        //        //    if (file.ContentType != _allowFileType)
        //        //    {
        //        //        return Task.FromResult<IActionResult>(BadRequest($"{file.FileName} is not valid PDF file."));
        //        //    }
        //        //    if (file.Length > _maxFileSize)
        //        //    {
        //        //        return Task.FromResult<IActionResult>(BadRequest($"{file.FileName} exceeds the maximum size of 2 MB."));
        //        //    }
        //        //    else if (file.Length < _maxFileSize)
        //        //    {
        //        //        var filePath = Path.Combine(cvTargetFolder, file.FileName);
        //        //        using var stream = new FileStream(filePath, FileMode.Create);
        //        //        file.CopyToAsync(stream);
        //        //    }

        //        //}
        //        //

        //        string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
        //        if (string.IsNullOrEmpty(lvToken)) { return RedirectToAction("Index", "Login"); }
        //        else
        //        {
        //            var lvClient = cvHttpClientFactory.CreateClient("TaskMgmtClient");
        //            lvClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {lvToken}");
        //            var lvCPBTask = new
        //            {
        //                pvInputModel.TaskPathId,
        //                TypeId = 0,
        //                SortIndex = 0,
        //                TaskName = pvInputModel.Taskname,
        //                Description = DBNull.Value,
        //                AssignTo = pvInputModel.Assign,
        //                StartDate = DBNull.Value,
        //                TargetDate = DBNull.Value,
        //                CategoryId = 1,
        //                SOPFolderPath = DBNull.Value,
        //                AttchMCode = DBNull.Value
        //            };
        //            var lvJsonData = JsonConvert.SerializeObject(lvCPBTask);
        //            var lvContent = new StringContent(lvJsonData, Encoding.UTF8, "application/json");
        //            var lvResponse = await lvClient.PostAsync("V1/CPBTask", lvContent);
        //            string lvReturnDataData = await lvResponse.Content.ReadAsStringAsync();
        //            if (lvResponse.IsSuccessStatusCode)
        //            {
        //                lvClient.Dispose();
        //                //return RedirectToAction("Index", "TaskMgmt");

        //                // add file 
        //                //string cvTargetFolder = @"C:\00.SourceCode\ZZZTemp\";
        //                var lv = JsonConvert.DeserializeObject<JResult>(lvReturnDataData);
        //                var lv2 = JsonConvert.DeserializeObject<Ab>(lv.jsonData);

        //                /////////////////////////////////////////////////////////////////////////////////
        //                string TaskId = "T89"; // Temporary test
        //                                       /////////////////////////////////////////////////////////////////////////////////

        //                var lvClient1 = cvHttpClientFactory.CreateClient("TaskMgmtClient");
        //                lvClient1.DefaultRequestHeaders.Add("Authorization", $"Bearer {lvToken}");


        //                //if (pvFile.Length > 0)
        //                //{
        //                //    //var filePath = Path.Combine(cvTargetFolder, file.FileName);
        //                //    using var stream = new FileStream("", FileMode.Create);
        //                //    await pvFile.CopyToAsync(stream);
        //                //}

        //                //foreach(var file in pvInputModel.FileToUpload.)
        //                //{

        //                //}

        //                var lvCPBFile = new
        //                {
        //                    TaskId,
        //                    pvInputModel.FileToUpload
        //                };
        //                var lvJsonData1 = JsonConvert.SerializeObject(lvCPBFile);
        //                var lvContent1 = new StringContent(lvJsonData1, Encoding.UTF8, "application/json");
        //                var lvResponse1 = await lvClient1.PostAsync("V1/CPBTaskAttchmnt", lvContent1);
        //                string lvReturnDataData1 = await lvResponse1.Content.ReadAsStringAsync();
        //                if (lvResponse1.IsSuccessStatusCode)
        //                {
        //                    return Ok(lvReturnDataData1);
        //                }
        //                else
        //                {
        //                    lvClient1.Dispose();
        //                    return BadRequest(lvReturnDataData1);
        //                }
        //            }
        //            else
        //            {
        //                lvClient.Dispose();
        //                return BadRequest(lvReturnDataData);
        //            }
        //        }
        //    }
        //    catch (Exception exc)
        //    {
        //        return null;
        //    }

        //}

        #endregion

        #region ---------- Other Action -----------------------------------------------------------------------------------

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        //}

        //public IActionResult Upload()
        //{
        //    return View();
        //}
        //[HttpGet]
        public async Task<IActionResult> GetCPBTaskById(string pvTaskId)
        {
            try
            {
                string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
                if (string.IsNullOrEmpty(lvToken)) { return RedirectToAction("Index", "Login"); }
                else
                {
                    var lvClient = cvHttpClientFactory.CreateClient("TaskMgmtClient");
                    lvClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {lvToken}");

                    var lvReqParams = new { TaskId = pvTaskId };
                    var lvReqParamsJson = JsonConvert.SerializeObject(lvReqParams);
                    var lvReqContent = new StringContent(lvReqParamsJson, Encoding.UTF8, "application/json");
                    var lvRequestMsg = new HttpRequestMessage
                    {
                        Method = HttpMethod.Get,
                        RequestUri = new Uri($"{ThisCPBWebApp.TaskMgmtBaseAddress}V1/CPBTask"),
                        Content = lvReqContent,
                    };
                    var lvResponse = await lvClient.SendAsync(lvRequestMsg);
                    var lvRspContent = await lvResponse.Content.ReadAsStringAsync();
                    if (lvResponse.IsSuccessStatusCode)
                    {
                        lvClient.Dispose();
                        return Ok(lvRspContent);
                    }
                    else
                    {
                        lvClient.Dispose();
                        return BadRequest(lvRspContent);
                    }
                }
            }
            catch (Exception exc)
            {
                return BadRequest(exc.Message);
            }
        }
        [HttpPost]
        public IActionResult GetCPBTaskById(CPBTaskModel pvTaskId)
        {
            try
            {
                string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
                if (string.IsNullOrEmpty(lvToken)) { return RedirectToAction("Index", "Login"); }
                else
                {
                    string lvBaseAddress = cvConfiguration.GetSection("WebApiEndpoint")["TaskMgmt"];
                    if (string.IsNullOrEmpty(lvBaseAddress)) { return null; }
                    HttpClientHandler HttpClientHandler = new() { ServerCertificateCustomValidationCallback = (message, cert, chain, sslPolicyErrors) => { return true; } };
                    var lvHttpClient = new HttpClient(HttpClientHandler)
                    {
                        BaseAddress = new Uri(lvBaseAddress)
                    };
                    lvHttpClient.BaseAddress = new Uri(lvBaseAddress);
                    lvHttpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + lvToken);
                    var CPBTaskData = new
                    {
                        pvTaskId.TaskId,
                        pvTaskId.TaskPathId,
                        TypeId = 0,
                        SortIndex = 0,
                        TaskName = pvTaskId.Taskname,
                        Description = DBNull.Value,
                        AssignTo = DBNull.Value,
                        StartDate = DBNull.Value,
                        TargetDate = DBNull.Value,
                        CategoryId = 3,
                        SOPFolderPath = DBNull.Value,
                        AttchMCode = DBNull.Value
                    };
                    var lvJsonData = JsonConvert.SerializeObject(CPBTaskData);
                    var lvContent = new StringContent(lvJsonData, Encoding.UTF8, "application/json");
                    // SendPost
                    HttpResponseMessage lvHttpRespMsg = lvHttpClient.PutAsync($"V1/CPBTask", lvContent).Result;
                    if (lvHttpRespMsg.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index", "TaskMgmt");
                    }
                    else
                    {
                        return BadRequest(lvHttpRespMsg.Content); ;
                    }
                }
            }
            catch (Exception exc)
            {
                return null;
            }
        }
        #endregion

        #region ---------- Class Helper -----------------------------------------------------------------------------------

        private async Task<WebApiReturnResultForTreeView> GetTreeViewData(string pvToken, int pvParent = 0)
        {
            try
            {
                var lvClient = cvHttpClientFactory.CreateClient("TaskMgmtClient");
                lvClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {pvToken}");
                var lvResponse = await lvClient.GetAsync("V1/TaskPath4TreeView");
                string lvResponseData = await lvResponse.Content.ReadAsStringAsync();
                if (lvResponse.IsSuccessStatusCode)
                {
                    lvClient.Dispose();
                    return JsonConvert.DeserializeObject<WebApiReturnResultForTreeView>(lvResponseData);
                }
                else
                {
                    lvClient.Dispose();
                    return null;
                }
            }
            catch (Exception exc)
            {
                return null;
            }
        }

        private static string Generate_CPBTreeView(List<CPBTreeNode> pvTreeNodeList)
        {
            var lvTreeviewHTML = new StringBuilder().Append("<UL id=\"id_ul_CPBTreeView\">\r\n");
            string lvHmlNodeLi = string.Empty;
            int lvCloseTagCount = 0;
            string lvULCloseTag = string.Empty;

            try
            {
                if (pvTreeNodeList is not null && pvTreeNodeList.Count > 0)
                {
                    for (int i = 0; i < pvTreeNodeList.Count; i++)
                    {
                        if (pvTreeNodeList[i].NodeType is not null && pvTreeNodeList[i].NodeType.Trim() != "")
                        {
                            lvHmlNodeLi = Generate_TreeViewNodeLI(pvTreeNodeList[i]);
                            if (pvTreeNodeList[i].Level == 0)
                            {
                                if (i == 0) lvTreeviewHTML.Append(lvHmlNodeLi);
                                else
                                {
                                    for (int j = 0; j < pvTreeNodeList[i - 1].Level - pvTreeNodeList[i].Level; j++)
                                    {
                                        lvULCloseTag = $"{lvULCloseTag}</ul>";
                                        lvCloseTagCount--;
                                    }
                                    lvTreeviewHTML.Append($"\r\n{lvULCloseTag}\r\n{lvHmlNodeLi}");
                                    lvULCloseTag = string.Empty;
                                }
                                if (i + 1 < pvTreeNodeList.Count && pvTreeNodeList[i].TaskPathId == pvTreeNodeList[i + 1].ParentId)
                                {
                                    lvTreeviewHTML.Append($"\r\n<ul id=\"ulId_{pvTreeNodeList[i].TaskPathId}\" class=\"ShowChild\">");
                                    lvCloseTagCount = 1;
                                }
                            }
                            else
                            {
                                if (pvTreeNodeList[i].Level < pvTreeNodeList[i - 1].Level)
                                {
                                    for (int j = 0; j < pvTreeNodeList[i - 1].Level - pvTreeNodeList[i].Level; j++)
                                    {
                                        lvULCloseTag = $"{lvULCloseTag}</ul>";
                                        lvCloseTagCount--;
                                    }
                                    lvTreeviewHTML.Append($"\r\n{lvULCloseTag}\r\n{lvHmlNodeLi}");
                                    lvULCloseTag = string.Empty;
                                }
                                else lvTreeviewHTML.Append($"\r\n{lvHmlNodeLi}");
                                if (i + 1 < pvTreeNodeList.Count && pvTreeNodeList[i].TaskPathId == pvTreeNodeList[i + 1].ParentId)
                                {
                                    lvTreeviewHTML.Append($"\r\n<ul id=\"ulId_{pvTreeNodeList[i].TaskPathId}\" class=\"ShowChild\">");
                                    lvCloseTagCount++;
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception exc)
            {
                lvTreeviewHTML = new("<li style = \"background-color: red;\">[RC000006]: Something wrong while rendering treeview.</li>");
                //Write to log File
                Console.WriteLine(exc.Message);

            }
            lvTreeviewHTML.Append("\r\n</ul>\"");
            return lvTreeviewHTML.ToString();
        }

        private static string Generate_TreeViewNodeLI(CPBTreeNode pvCPBTreeNode)
        {
            var lvSB = new StringBuilder();
            lvSB.Append($"<li>");
            if (pvCPBTreeNode.NodeType == "P")
            {
                lvSB.Append($" <img id=\"tgglId_{pvCPBTreeNode.TaskPathId}\" onclick=\"ImgPathToggle(this)\" src=\"https://10.2.247.36:36502/iconv1/IFA1023.ico\" style=\"width: 18px; height: 18px;\">");
                lvSB.Append($" <span class=\"UnselectedNode\" id=\"pId_{pvCPBTreeNode.TaskPathId}\"");
                lvSB.Append($" onclick=\"Node_OnClick(this)\" oncontextmenu='NodeContextMenu(event, this, \"P\")'>");
                lvSB.Append($" {pvCPBTreeNode.ShortName}</span>");
            }
            else if (pvCPBTreeNode.NodeType == "T")
            {
                lvSB.Append($" <img id=\"tgglId_{pvCPBTreeNode.TaskPathId}\" onclick=\"ImgPathToggle(this)\" src=\"https://10.2.247.36:36502/iconv1/IFA102.ico\" style=\"width: 18px; height: 18px;\">");
                lvSB.Append($" <span class=\"UnselectedNode\" id=\"tId_{pvCPBTreeNode.TaskPathId}\"");
                lvSB.Append($" onclick=\"Node_OnClick(this)\" oncontextmenu='NodeContextMenu(event, this, \"T\")'>");
                lvSB.Append($" {pvCPBTreeNode.ShortName}</span>");
            }
            lvSB.Append("</li>");
            return lvSB.ToString();
        }

        #endregion

    }

}
