using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using WebAppTaskMgmt.Models;

namespace WebAppTaskMgmt.Controllers
{
    public partial class LoginController(ILogger<LoginController> pvLogger, IConfiguration pvConfiguration, IHttpClientFactory pvIHttpClientFactory) : Controller
    {

        private readonly ILogger<LoginController> cvLogger = pvLogger;
        private readonly IConfiguration cvConfiguration = pvConfiguration;
        private readonly IHttpClientFactory cvHttpClientFactory = pvIHttpClientFactory;

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(ReqLoginInfo pvLoginInfo)
        {
            /*************************************************************************************************
            string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
            if (!string.IsNullOrEmpty(lvToken)) return RedirectToAction("Index", "Home");
             *************************************************************************************************/
            if (pvLoginInfo is null)
            {
                ViewBag.Message = "Please Provide Login Information.";
                return View();
            }
            if (ModelState.IsValid)
            {
                string lvClient_id = pvConfiguration.GetSection("ThisCPBWebApp")["ClientId"];
                var lvClient = cvHttpClientFactory.CreateClient("AuthKeyClient");
                var lvFormData = new FormUrlEncodedContent(
                [ new KeyValuePair<string, string>("Grant_type", "Password")
                , new KeyValuePair<string, string>("Client_id", lvClient_id)
                , new KeyValuePair<string, string>("Username", pvLoginInfo.Usrname)
                , new KeyValuePair<string, string>("Password", pvLoginInfo.Passwrd)]);
                var lvResponse = await lvClient.PostAsync("IntAuth/V1/AccessToken", lvFormData);
                string lvReturnDataData = await lvResponse.Content.ReadAsStringAsync();
                if (lvResponse.IsSuccessStatusCode)
                {
                    lvClient.Dispose();
                    var lvTokenInfo = JsonConvert.DeserializeObject<CPBAccessToken>(lvReturnDataData);
                    HttpContext.Session.SetString("fue3aiks173eW0t2y75K4e62V3H7k8z1", lvTokenInfo.Name);
                    HttpContext.Session.SetString("h1a37834jkd9mx93c6ygsj3tr9013jfu", lvTokenInfo.Access_token);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    lvClient.Dispose();
                    ViewBag.Message = "Please Provide Login Information.";
                    return RedirectToAction("Index", "Login");
                }
            }
            else
            {
                ViewBag.Message = "Please enter required information.";
                return View();
            }
        }

        public IActionResult Index()
        {
            ViewBag.NeedToLogin = true;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error(string pvMessage)
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier, Message = pvMessage });
        }

        #region ---------- Helper -------------------------------------------------------------------

        #endregion
    }

}
