using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebAppTaskMgmt.Models;

namespace WebAppTaskMgmt.Controllers
{

    public partial class HomeController(ILogger<HomeController> pvLogger, IConfiguration pvConfiguration) : Controller
    {
        private readonly ILogger<HomeController> cvLogger = pvLogger;
        private readonly IConfiguration cvConfiguration = pvConfiguration;

        public IActionResult Index()
        {
            string lvToken = HttpContext.Session.GetString("h1a37834jkd9mx93c6ygsj3tr9013jfu");
            if (string.IsNullOrEmpty(lvToken))
            {
                return RedirectToAction("Index", "Login");
            }
            else return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }

}
