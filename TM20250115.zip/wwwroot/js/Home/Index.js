﻿const cvPContextMenu = document.getElementById('id_PContextMenu');
const cvTContextMenu = document.getElementById('id_TContextMenu');
const cvPopUpNewPath = document.getElementById('id_PopUpNewPath');
const cvPopUpNewTask = document.getElementById('id_PopUpNewTask');
const cvParent = document.getElementById("InputParentId");

document.addEventListener('click', () => {
    cvPContextMenu.style.display = 'none';
    cvTContextMenu.style.display = 'none';
});

/*******************************************************************************************************/
function ImgPathToggle(toggleImage) {
    var lvFound = document.getElementById('ulId_' + toggleImage.id.substring('tgglId_'.length, toggleImage.id.length));
    if (lvFound != null) {
        //alert(lvFound.className);
        if (lvFound.className == 'HideChild') {
            lvFound.className = 'ShowChild';
        }
        else {
            lvFound.className = 'HideChild';
        }
    }
}
function Node_OnClick(ThisNode) {
    var lvSp = document.getElementsByClassName('SelectedNode');
    for (var i = 0; i < lvSp.length; i++) lvSp[i].className = 'UnselectedNode'
    ThisNode.className = 'SelectedNode';
    cvSelectedNodeId = ThisNode.id;
    cvSelectedNodeText = ThisNode.textContent;
}

function NodeContextMenu(pvEvent, pvThisNode, pvNodeType) {
    pvEvent.preventDefault();
    cvPContextMenu.style.display = 'none';
    cvTContextMenu.style.display = 'none';
    Node_OnClick(pvThisNode);
    if (pvNodeType == 'P') {
        cvPContextMenu.style.top = pvEvent.clientY - 5 + 'px';
        cvPContextMenu.style.left = pvEvent.clientX + 'px';
        cvPContextMenu.style.display = "block";
    } else if (pvNodeType == 'T') {
        cvTContextMenu.style.top = pvEvent.clientY + 'px';
        cvTContextMenu.style.left = pvEvent.clientX + 'px';
        cvTContextMenu.style.display = 'block';
    }
}
function menuAction(pvMenuName) {
    if (pvMenuName == 'NewPath') {
        cvPopUpNewPath.style.display = 'block';
        cvParent.value = cvSelectedNodeText;
    }
    else if (pvMenuName == 'NewTask') {
        cvPopUpNewTask.style.display = 'block';
    }
}
function PopupClose(pvPopupId) {
    if (pvPopupId.id == "ButtonClose_PopUpNewPath")
        cvPopUpNewPath.style.display = 'none';
    else if (pvPopupId.id == "ButtonClose_PopUpNewTask")
        cvPopUpNewTask.style.display = 'none';
}
/*******************************************************************************************************/
function getDesc() {
    //pendding
    const pedID = document.getElementById('pend').value;
    const hidepend = document.getElementById('pend');
    //Imprograss
    const inprID = document.getElementById('inpro').value;
    const hideinpro = document.getElementById('inpro');
    //select value 
    const selectPed = document.getElementById("options");
    const selectValuePed = selectPed.value;
    const selectInpro = document.getElementById("options");
    const selectValueInpro = selectInpro.value;
    if (pedID == selectValuePed) {
        hidepend.style.display = "block";
        hideinpro.style.display = "none";
    } else if (inprID == selectValueInpro) {
        hidepend.style.display = "none";
        hideinpro.style.display = "block";
    } 
    else if (pedID != selectValuePed || inprID != selectValueInpro) {
       hidepend.style.display = "none";
       hideinpro.style.display = "none";
    }
 
}