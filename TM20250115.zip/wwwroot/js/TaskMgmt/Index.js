﻿const cvPContextMenu = document.getElementById('id_PContextMenu');
const cvTContextMenu = document.getElementById('id_TContextMenu');
const cvPopUpNewPath = document.getElementById('id_PopUpNewPath');
const cvPopUpEditPath = document.getElementById('id_PopUpEditPath');
const cvPopUpNewTask = document.getElementById('id_PopUpNewTask');
const cvPopUpDeletePath = document.getElementById('id_PopUpDeletePath');
const cvPopUpEditTask = document.getElementById('id_PopUpEditTask');
const cvPopUpViewDaily = document.getElementById('id_PopUpViewDaily');
const cvParentId = document.getElementById("id_Parent");
const cvTaskPathId = document.getElementById("id_TaskPathId");
const cvTaskId = document.getElementById('id_Task');
const cvTaskName = document.getElementById('id_TaskName');
var cvGetDesc = document.getElementById("id_Desc");
var cvParentEditId = document.getElementById("id_EditParent");
var cvParentDeleteId = document.getElementById("id_DelParentId");
var cvParentEditPathName = document.getElementById("id_EditPathName");
var cvParentDelPathName = document.getElementById("id_DelPathName");


document.addEventListener('click', () => {
    cvPContextMenu.style.display = 'none';
    cvTContextMenu.style.display = 'none';
});

/*******************************************************************************************************/
function ImgPathToggle(toggleImage) {
    var lvFound = document.getElementById('ulId_' + toggleImage.id.substring('tgglId_'.length, toggleImage.id.length));
    if (lvFound != null) {
        //alert(lvFound.className);
        if (lvFound.className == 'HideChild') {
            lvFound.className = 'ShowChild';
        }
        else {
            lvFound.className = 'HideChild';
        }
    }
}
function Node_OnClick(ThisNode) {
    var lvSp = document.getElementsByClassName('SelectedNode');
    for (var i = 0; i < lvSp.length; i++) lvSp[i].className = 'UnselectedNode'
    ThisNode.className = 'SelectedNode';
    cvSelectedNodeText = ThisNode.textContent;
    cvSelectedNodeId = ThisNode.id;
    //EditTaskpath
    cvSelectedEditNodeId = ThisNode.id;
    //CreateNewTask
    cvSelectedTaskNodeId = ThisNode.id;
    cvSelectedTaskNodeText = ThisNode.textContent;
}
function NodeContextMenu(pvEvent, pvThisNode, pvNodeType) {
    pvEvent.preventDefault();
    cvPContextMenu.style.display = 'none';
    cvTContextMenu.style.display = 'none';
    Node_OnClick(pvThisNode);
    if (pvNodeType == 'P') {
        cvPContextMenu.style.top = pvEvent.clientY - 5 + 'px';
        cvPContextMenu.style.left = pvEvent.clientX + 'px';
        cvPContextMenu.style.display = "block";
    } else if (pvNodeType == 'T') {
        cvTContextMenu.style.top = pvEvent.clientY - 5 + 'px';
        cvTContextMenu.style.left = pvEvent.clientX + 'px';
        cvTContextMenu.style.display = 'block';
    }
}

function menuAction(pvMenuName) {
    if (pvMenuName == 'NewPath') {
        cvParentId.style.display = "none";
        cvPopUpNewPath.style.display = 'block';
        let index = cvSelectedNodeId.indexOf('_');
        let number = cvSelectedNodeId.substring(index + 1);
        cvParentId.value = number;
        cvGetDesc.textContent = cvSelectedNodeText;
    }
    else if (pvMenuName == 'NewTask') {
        cvPopUpNewTask.style.display = 'block';
        let index = cvSelectedTaskNodeId.indexOf('_');
        let number = cvSelectedTaskNodeId.substring(index + 1);
        cvTaskPathId.value = number;
    } else if (pvMenuName == 'EditPath') {
        cvPopUpEditPath.style.display = 'block';
        let index = cvSelectedNodeId.indexOf('_');
        let number = cvSelectedNodeId.substring(index + 1);
        cvParentEditId.value = number;
        cvParentEditPathName.value = cvSelectedNodeText;
    } else if (pvMenuName == 'DelPath') {
        cvPopUpDeletePath.style.display = 'block';
        let index = cvSelectedNodeId.indexOf('_');
        let number = cvSelectedNodeId.substring(index + 1);
        cvParentDeleteId.value = number;
        cvParentDelPathName.value = cvSelectedNodeText;
    } else if (pvMenuName == 'EditCPBTask') {
        cvPopUpEditTask.style.display = 'block';
        let index = cvSelectedNodeId.indexOf('_');
        let number = cvSelectedNodeId.substring(index + 1);
        cvTaskId.value = number;
        cvTaskName.value = cvSelectedTaskNodeText;
    } else if (pvMenuName == 'SubmitDaily') {
        cvPopUpViewDaily.style.display = 'block';
        let index = cvSelectedNodeId.indexOf('_');
        let number = cvSelectedNodeId.substring(index + 1);
        /*    cvTaskId.value = number;*/
        cvTaskName.value = cvSelectedTaskNodeText;
    }

}
function PopupClose(pvPopupId) {
    if (pvPopupId.id == "ButtonClose_PopUpNewPath")
        cvPopUpNewPath.style.display = 'none';
    else if (pvPopupId.id == "ButtonClose_PopUpNewTask")
        cvPopUpNewTask.style.display = 'none';
    else if (pvPopupId.id == "ButtonClose_PopUpEditPath")
        cvPopUpEditPath.style.display = 'none';
    else if (pvPopupId.id == "ButtonClose_PopUpDeletePath")
        cvPopUpDeletePath.style.display = 'none';
    else if (pvPopupId.id == "ButtonClose_PopUpEditTask")
        cvPopUpEditTask.style.display = 'none';
}
/*******************************************************************************************************/
function getContent() {
    // Check options
    const cvSelectValue = document.getElementById('id_Options').value;
    const cvCheckPend = document.getElementById('id_Pending').value;
    const cvCheckInpro = document.getElementById('id_Inpro').value;
    //show input groups
    const cvInputName = document.getElementById('id_InputName');
    const cvRemark = document.getElementById('id_Remark');
    const cvInputPer = document.getElementById('id_InputNum');
    const cvLabel = document.getElementById('id_Label');
    if (cvCheckPend == cvSelectValue) {
        cvInputPer.style.display = 'none';
        cvRemark.style.display = 'block';
        cvInputName.style.display = 'block';
        cvLabel.style.display = 'none';
    } else if (cvCheckInpro == cvSelectValue) {
        cvRemark.style.display = 'none';
        cvInputName.style.display = 'none';
        cvInputPer.style.display = 'block';
        cvLabel.style.display = 'block';
    }

}